﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebAPI.Models;

namespace WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SubGroupController : ControllerBase
    {
        private readonly AmazoneDBContext _context;

        public SubGroupController(AmazoneDBContext context)
        {
            _context = context;
        }

        // GET: api/SubGroup
        [HttpGet]
        public async Task<ActionResult<IEnumerable<SubGroup>>> GetSubGroups()
        {
            return await _context.SubGroups.ToListAsync();
        }

        // GET: api/SubGroup/5
        [HttpGet("{id}")]
        public async Task<ActionResult<SubGroup>> GetSubGroup(int id)
        {
            var subGroup = await _context.SubGroups.FindAsync(id);

            if (subGroup == null)
            {
                return NotFound();
            }

            return subGroup;
        }

        // PUT: api/SubGroup/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutSubGroup(int id, SubGroup subGroup)
        {
            if (id != subGroup.SubGroupId)
            {
                return BadRequest();
            }

            _context.Entry(subGroup).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!SubGroupExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/SubGroup
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<SubGroup>> PostSubGroup(SubGroup subGroup)
        {
            _context.SubGroups.Add(subGroup);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetSubGroup", new { id = subGroup.SubGroupId }, subGroup);
        }

        // DELETE: api/SubGroup/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteSubGroup(int id)
        {
            var subGroup = await _context.SubGroups.FindAsync(id);
            if (subGroup == null)
            {
                return NotFound();
            }

            _context.SubGroups.Remove(subGroup);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool SubGroupExists(int id)
        {
            return _context.SubGroups.Any(e => e.SubGroupId == id);
        }
    }
}
