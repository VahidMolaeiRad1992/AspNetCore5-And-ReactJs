﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPI.Models
{
    public class orderDetailInfo
    {
        public int ProductId { get; set; }
        public int Price { get; set; }
        public int Count { get; set; }

    }
}
