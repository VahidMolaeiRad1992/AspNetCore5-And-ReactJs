import React from 'react'

function Footer() {
	return (
		<div >
			کلیه حقوق مادی و معنوی این اثر متعلق به این فروشگاه میباشد.
		</div>
	)
}

export default Footer
