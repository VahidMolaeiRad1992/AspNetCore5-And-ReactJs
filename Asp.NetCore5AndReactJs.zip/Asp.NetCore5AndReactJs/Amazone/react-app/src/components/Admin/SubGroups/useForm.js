import React from 'react'

const useForm = (initialFieldValues,validate,setCurrentId) => {
  
  const [values, setValues] = React.useState(initialFieldValues);
  
  const [errors,setErrors]=React.useState({})
  
   const handelChangeInput=e=>{
		let {name,value}=e.target
		let fieldValue={[name]:value}
		setValues({
			...values,
			...fieldValue,
			[name]:value
		})
     validate(fieldValue)

	}
  
  
  const resetForm = () => {
    setValues({
      ...initialFieldValues
    })
    setErrors({})
    setCurrentId(0)
  }
  return {
    values,
    setValues,
    errors,
    setErrors,
    handelChangeInput,
    resetForm
  }
}

export default useForm
