import * as actions from "../../../Redux/Actions/Groups/GroupAction";
import * as action from "../../../Redux/Actions/SubGroups/SubGroupAction"
import { Button, FormControl, FormHelperText, Grid, InputLabel, MenuItem, Select, TextField,withStyles } from '@material-ui/core'
import React from 'react'

import { connect } from "react-redux";
import {useToasts} from 'react-toast-notifications'


const styles = theme => ({
    root: {
      '& .MuiTextField-root': {
      margin: theme.spacing(1),
      minWidth:230
    }
  },
  formControl: {
    margin: theme.spacing(1),
      minWidth:230
  },
  smMargin: {
    margin: theme.spacing(1),
  }
})

const initialFieldValues={
	subGroupId:'',
	groupId:''
}

function SubGroupForm({classes,...props}) {


	const { addToast } = useToasts();
	const [values, setValues] = React.useState(initialFieldValues);
	
	const [errors,setErrors]=React.useState({})

	const validate=(fieldsValues=values)=>{
		let temp ={...errors}
		if('subGroupName' in fieldsValues)
		temp.subGroupName=fieldsValues.subGroupName?"":"This field is required";
		if('groupId' in fieldsValues)
		temp.groupId=fieldsValues.groupId?"":"This field is required";
		setErrors({
			...temp
		})
		if(fieldsValues === values)
		return Object.values(temp).every(x=>x==="")
	}

	
	

	const inputLabel = React.useRef(null);
	  const [labelWidth, setLabelWidth] = React.useState(0);
  	React.useEffect(() => {
    	setLabelWidth(inputLabel.current.offsetWidth)
  	},[]);
	  const resetForm = () => {
		setValues({
		  ...initialFieldValues
		})
		setErrors({})
	      props.setCurrentId(0)
	   }

    React.useEffect(() => {
       props.fetchAllGroups()
    })

	React.useEffect(()=>{
		if(props.currentId !==0){
			setValues({
				...props.subGroupList.find(x=>x.subGroupId===props.currentId)
			})
			setErrors({})
		}
	},[props.currentId, props.subGroupList, setErrors, setValues])

	
	const handelSubmit=e=>{
		e.preventDefault();
		if(validate()){
			const onSuccess=()=>{
				resetForm()
				addToast("Submitted Successfully.",{appearance:'success'})
			}
			if(props.currentId ===0){
				props.createSubGroup(values,onSuccess)
			}
			
			else {
				props.updateSubGroup(props.currentId ,values,onSuccess)
			}
		}
		
	}

	const handelChangeInput=e=>{
		let {name,value}=e.target
		let fieldValue={[name]:value}
		setValues({
			...values,
			...fieldValue,
			[name]:value
		})
     validate(fieldValue)

	}
	return (
		<form noValidate autoComplete="off" className={classes.root} onSubmit={handelSubmit}>
			<Grid container>
				<Grid item xs={6}>
					<TextField 
					name="subGroupName"
					variant="outlined"
					label="SubGroup Name"
					value={values.subGroupName}
					onChange={handelChangeInput}
					{...(errors.subGroupName && {error:true , helperText:errors.subGroupName} )}
					/>

					
				</Grid>
				<Grid item xs={6}>
					<FormControl variant="outlined"
					     className={classes.formControl}
						{...(errors.groupId && {error:true})}
					>
						<InputLabel ref={inputLabel}>Group Name</InputLabel>
						<Select 
							name="groupId"
							value={values.groupId}
							onChange={handelChangeInput}	
							labelWidth={labelWidth}
						>
							{
								props.GroupList.map((row,index)=>{
									return(
								          <MenuItem key={index} value={row.groupId} >
										 	{row.groupName}
										</MenuItem>
									)
								})
							}
						</Select>
						{errors.groupId && <FormHelperText>{errors.groupId}</FormHelperText>}
					</FormControl>
				</Grid>
				<Button className={classes.smMargin} type="submit" variant="contained" color="primary">Submit</Button>
				&nbsp;&nbsp;&nbsp;&nbsp;
            		<Button 
				     className={classes.smMargin} 
				     variant="contained" 
				     color="secondary"  
					onClick={resetForm}
				>Reset</Button>
			</Grid>
		</form>
	)
}
const mapStateToProps = state =>({
 GroupList:state.Group.list,
 subGroupList:state.SubGroup.subList
})
const mapActionsToProps = {
  fetchAllGroups: actions.fetchAll,
  createSubGroup:action.createSubGroup ,
  updateSubGroup:action.update
 
}

export default connect(mapStateToProps,mapActionsToProps)(withStyles(styles)(SubGroupForm))
