import React from 'react'
import { Button, ButtonGroup, Grid, Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow,withStyles } from '@material-ui/core'
import SubGroupForm from './SubGroupForm';
import * as actions from '../../../Redux/Actions/SubGroups/SubGroupAction'
import { connect } from 'react-redux';
import  EditIcon  from '@material-ui/icons/Edit';
import  DeleteIcon  from '@material-ui/icons/Delete';
import {useToasts} from 'react-toast-notifications'

const styles=theme => ({

	 root: {
		'& .MuiTableCell-head': {
		fontSize:"1.25rem"
	     }
	},

	paper:{
		margin:theme.spacing(2),
		padding:theme.spacing(2)
	}
}) 


function SubGroup({classes,...props}) {

	const { addToast } = useToasts();
	const [currentId,setCurrentId]=React.useState(0)

	React.useEffect(()=>{
	props.fetchAllSubGroups()
	}) 

	const onDelete=id=>{
		if(window.confirm('Are you sure to delete this record?'))
		props.deleteSubGroup(id,()=>addToast("Deleted Successfully.",{appearance:'info'}))
	}

  return (
	<Paper className={classes.paper} elevation={8}>
		<Grid container>
			<Grid item xs={6}>
				<SubGroupForm {...({currentId,setCurrentId})} />
			</Grid>
			<Grid item xs={6}>
				<TableContainer>
					<Table>
						<TableHead className={classes.root}>
							<TableRow>
								<TableCell>
									SubGroup Name
								</TableCell> 
								<TableCell>
									Group ID
								</TableCell> 
								 <TableCell></TableCell>
							</TableRow>  
						</TableHead>
						  <TableBody>
							{
								props.SubGroupList.map((record, index) => {
									return (
										<TableRow key={index} hover>
											  <TableCell>{ record.subGroupName}</TableCell>  
											  <TableCell>{ record.groupId}</TableCell>  
											 <TableCell>
												<ButtonGroup variant="text">
													<Button>
														<EditIcon color="primary"
															onClick={()=>{setCurrentId(record.subGroupId)}}
														/>
													</Button>
													<Button>
														<DeleteIcon color="secondary"
															onClick={()=>onDelete(record.subGroupId)} />
														</Button>
												</ButtonGroup>
											 </TableCell>
									    </TableRow>  
								    )
							    })
						     }
						</TableBody>  
					</Table>
						  
				</TableContainer>
			</Grid>
				
		</Grid>
	</Paper>
  )
}
const mapStateToProps = state =>({
 SubGroupList:state.SubGroup.subList,
 
})
const mapActionsToProps = {
  fetchAllSubGroups: actions.fetchAll,
  deleteSubGroup:actions.Delete
  
}
export default connect(mapStateToProps, mapActionsToProps)(withStyles(styles) (SubGroup))

