import React from 'react'
const defaultImageSrc="/img/1.png"

const useForm = (initialFieldValues,validate) => {
  
  const [values, setValues] = React.useState(initialFieldValues);
  
  const [errors,setErrors]=React.useState({})

  
   const handelChangeInput=e=>{
		let {name,value}=e.target
		let fieldValue={[name]:value}
		setValues({
			...values,
			...fieldValue,
			[name]:value
		})
     validate(fieldValue)

	}

	const showPreview = e => {
		if (e.target.files && e.target.files[0]) {
			let imageFile = e.target.files[0];
			const reader = new FileReader();
			reader.onload = x => {
				setValues({
					...values,
					imageFile,
					imageSrc:x.target.result
				})
			}
			reader.readAsDataURL(imageFile)
		}
		else {
			setValues({
			...values,
			imageFile:null,
			imageSrc:defaultImageSrc
			})
		}
  }
  
  
  const resetForm = () => {
    setValues({
      ...initialFieldValues
    })
    setErrors({})
    //setCurrentId(0)
  }
  return {
    values,
    setValues,
    errors,
    setErrors,
    handelChangeInput,
    resetForm,
    showPreview
  }
}


export default useForm