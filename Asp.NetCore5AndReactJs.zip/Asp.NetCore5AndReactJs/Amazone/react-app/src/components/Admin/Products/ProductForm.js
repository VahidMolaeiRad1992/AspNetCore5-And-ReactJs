/* eslint-disable jsx-a11y/alt-text */
import { Grid,TextField,FormControl,InputLabel,Select,MenuItem,withStyles,Button ,FormHelperText } from '@material-ui/core'
import React from 'react'
import { connect } from 'react-redux';
import * as ProductActions from "../../../Redux/Actions/Products/ProductAction";
import * as actions from "../../../Redux/Actions/SubGroups/SubGroupAction"


const styles = theme => ({
    root: {
      '& .MuiTextField-root': {
      margin: theme.spacing(1),
      minWidth:230
    }
  },
  formControl: {
    margin: theme.spacing(1),
      minWidth:230
  },
  smMargin: {
    margin: theme.spacing(1),
  }
})


const defaultImageSrc="/img/1.png"

const initialFieldValues={
	productId:0,
	title:'',
	price:'',
	description:'',
	subGroupId:'',
	imageName:'',
	imageSrc: defaultImageSrc,
     imageFile:null
	
}

 function ProductForm({classes,...props}) {

	 const{addOrEdit}=props

	// const { addToast } = useToasts();

	const [values, setValues] = React.useState(initialFieldValues);
  
  	const [errors,setErrors]=React.useState({})


	 const validate=(fieldsValues=values)=>{
		let temp ={...errors}
		if('title' in fieldsValues)
		temp.title=fieldsValues.title?"":"This field is required";
		
		if('price' in fieldsValues)
		temp.price=fieldsValues.price?"":"This field is required";

		if('description' in fieldsValues)
		temp.description=fieldsValues.description?"":"This field is required";

		if('subGroupId' in fieldsValues)
		temp.subGroupId=fieldsValues.subGroupId?"":"This field is required";
		setErrors({
			...temp
		})
		if(fieldsValues === values)
		return Object.values(temp).every(x=>x==="")
	}

	const inputLabel = React.useRef(null);
  	const [labelWidth, setLabelWidth] = React.useState(0);

  	React.useEffect(() => {
    	setLabelWidth(inputLabel.current.offsetWidth)
  	},[]);

	
    React.useEffect(() => {
       props.fetchAllSubGroups()
    },[])



	const handelChangeInput=e=>{
		let {name,value}=e.target
		let fieldValue={[name]:value}
		setValues({
			...values,
			...fieldValue,
			[name]:value
		})
     validate(fieldValue)

	}



	const resetForm=()=>{
		setValues(initialFieldValues)
		document.getElementById('image-uploader').value=null
		setErrors({})
	} 

	const handelSubmit=e=>{
		e.preventDefault();
		if(validate()){
			//const onSuccess=()=>{
			//		//resetForm()
			//		addToast("Submitted Successfully.",{appearance:'success'})
			//	}
			const formData = new FormData();
				formData.append('productId',values.productId)
				formData.append('title', values.title)
				formData.append('price', values.price)
				formData.append('description', values.description)
				formData.append('subGroupId', values.subGroupId)
				formData.append('imageName', values.imageName)
				formData.append('imageFile', values.imageFile)

			addOrEdit(formData,resetForm)
		}	
	}


const showPreview = e => {
		if (e.target.files && e.target.files[0]) {
			let imageFile = e.target.files[0];
			const reader = new FileReader();
			reader.onload = x => {
				setValues({
					...values,
					imageFile,
					imageSrc:x.target.result
				})
			}
			reader.readAsDataURL(imageFile)
		}
		else {
			setValues({
			...values,
			imageFile:null,
			imageSrc:defaultImageSrc
			})
		}
     }

	return (
		<form  noValidate autoComplete="off" className={classes.root} onSubmit={handelSubmit}>
			<Grid container>
				<Grid item xs={6}>
					<TextField 
					name="title"
					label="عنوان"
					value={values.title}
					onChange={handelChangeInput}
					{...(errors.title && {error:true , helperText:errors.title} )}
					/>
					<TextField 
					name="price"
					label="قیمت"
					value={values.price}
					onChange={handelChangeInput}
					{...(errors.price && {error:true , helperText:errors.price} )}
					/>
					<FormControl 
					     className={classes.formControl}
						{...(errors.subGroupId && {error:true})}
					>
						<InputLabel ref={inputLabel}>نام زیر گروه</InputLabel>
						<Select 
							name="subGroupId"
							value={values.subGroupId}
							onChange={handelChangeInput}	
							labelWidth={labelWidth}
							
						>
							{
								props.subGroupList.map((row,index)=>{
									return(
								          <MenuItem key={index} value={row.subGroupId} >
										 	{row.subGroupName}
										</MenuItem>
									)
								})
							}
						</Select>
						{errors.subGroupId && <FormHelperText>{errors.subGroupId}</FormHelperText>}
					</FormControl>

					<TextField 
					name="description"
					
					label="توضیحات"
					value={values.description}
					onChange={handelChangeInput}
					{...(errors.description && {error:true , helperText:errors.description} )}
					/>	
				</Grid>
				<Grid item xs={6}>
					
					<img src={values.imageSrc} className="card-image-top" height="250px" />
					<input
					type="file"
					
					id="image-uploader"
					accept="image/*"
                		onChange={showPreview}
					
					/>
				</Grid>
			</Grid>

			<Button className={classes.smMargin} type="submit" variant="contained" color="primary">ثبت</Button>
				&nbsp;&nbsp;&nbsp;&nbsp;
            		<Button 
				     className={classes.smMargin} 
				     variant="contained" 
				     color="secondary"  
					
				>پاک کردن</Button>
		</form>
	)
}

const mapStateToProps = state =>({
 subGroupList:state.SubGroup.subList,
 ProductList:state.Product.pList
})
const mapActionsToProps = {	
  fetchAllSubGroups: actions.fetchAll,
  createProduct:ProductActions.create,
  updateProduct:ProductActions.update
 
}

export default connect(mapStateToProps,mapActionsToProps)(withStyles(styles)(ProductForm))
