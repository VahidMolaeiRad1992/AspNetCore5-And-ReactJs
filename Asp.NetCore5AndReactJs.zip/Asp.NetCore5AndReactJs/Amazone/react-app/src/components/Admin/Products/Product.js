/* eslint-disable jsx-a11y/alt-text */
import { Button, ButtonGroup, Grid, Paper,Table,TableBody,TableCell,TableContainer,TableHead,TableRow,withStyles } from '@material-ui/core'
import React from 'react'
import ProductForm from './ProductForm'
import * as action from '../../../Redux/Actions/Products/ProductAction'
import { connect } from 'react-redux';
import axios from 'axios';
import  EditIcon  from '@material-ui/icons/Edit';
import  DeleteIcon  from '@material-ui/icons/Delete';




const styles = theme => ({
    root: {
      '& .MuiTableCell-head': {
		fontSize:"1.25rem"
	     }
    
  },
  formControl: {
    margin: theme.spacing(1),
      minWidth:230
  },
  smMargin: {
    margin: theme.spacing(1),
  },
  h1:{
	  margin: theme.spacing(2),
	  padding: theme.spacing(3),
	  textAlign:'center',
	  backgroundColor:'rgb(151, 151, 156)',
	  color:'white'
  },
  paper:{
		margin:theme.spacing(2),
		padding:theme.spacing(2)
	},
	table:{
		minWidth: 1000
	}
})



 function Product({classes,...props}) {

	
	const [productList, setProductList] = React.useState([])
	const [recordForEdit, setRecordForEdit] = React.useState(null)
	
 const ProductAPI= (url='https://localhost:44364/api/Product/')=>{

	   return {

		fetchAllProduct: () => axios.get(url),
		fetchByIdProduct:id=>axios.get(url+id),
		createProduct: newRecord => axios.post(url, newRecord),
		updateProduct: (id, updateRecord) => axios.put(url + id, updateRecord),
		deleteProduct:id=>axios.delete(url+id)
	   }
  }



	 const addOrEdit=(formData,onSuccess)=>{
		if (formData.get('productId') === "0") {
		 ProductAPI().createProduct(formData)
		 .then(res=>{
			 onSuccess();
		 })
		 .catch(err=>console.log(err))
		 
			
		 }
		 else{
			ProductAPI().updateProduct(formData.get('productId'), formData)
			.then(res => {
			  onSuccess();
			  refreshProductList();
			})
			.catch(err => console.log(err))
		 }
	 }
		 
	 React.useEffect(() => {
		refreshProductList();
	 },[]) 
	
	function refreshProductList() {
		ProductAPI().fetchAllProduct()
		    .then(res => {
			 setProductList(res.data)
			 
		    })
		   .catch(err => console.log(err))
		 
    }

    const onDelete = id => {
	if (window.confirm('Are you sure to delete this record?'))
	    ProductAPI().deleteProduct(id)
		   .then(res => refreshProductList())
		   .catch(err => console.log(err))
 }

	return (
		<div>
			<Paper className={classes.h1} elevation={8}>
				<h2 className={classes.h1}>محصولات</h2>
			</Paper>

			<Paper className={classes.paper}>
				<Grid >
					<Paper className={classes.paper} elevation={8}>
						<Grid container item xs={10}>
							<ProductForm addOrEdit={addOrEdit}/>	
						</Grid>
					
					
					</Paper>
					<Paper className={classes.smMargin} elevation={8}>
							<Grid >
								<TableContainer component={Paper}>
									<Table className={classes.table} >
										<TableHead >
											<TableRow>
												<TableCell>شماره</TableCell>
												<TableCell>عنوان</TableCell>
												<TableCell>قیمت</TableCell>
												<TableCell>توضیحات</TableCell>
												<TableCell>شماره زیر گروه</TableCell>
												<TableCell>تصویر</TableCell>
												<TableCell></TableCell>
											</TableRow>
										</TableHead>
										<TableBody>
											
										{
										     productList.map((record,index)=>{
												return(
													<TableRow key={index}>
														<TableCell>{record.productId}</TableCell>
														<TableCell>{record.title}</TableCell>
														<TableCell>{record.price}</TableCell>
														<TableCell>{record.description}</TableCell>
														<TableCell>{record.subGroupId}</TableCell>
														<TableCell  size="small"><img src={record.imageSrc} width="35%" /></TableCell>
                                                        <ButtonGroup variant="text">
													<Button>
														<EditIcon color="primary"
															onClick={()=>{setRecordForEdit(record.productId)}}
														/>
													</Button>
													<Button>
														<DeleteIcon color="secondary"
															onClick={()=>onDelete(record.productId)} />
														</Button>
												</ButtonGroup>
													</TableRow>
												)
												
											})
										}

											
										</TableBody>
									</Table>
								</TableContainer>
							</Grid>
				
					</Paper>
				</Grid>
			</Paper>
		</div>


	)
}

const mapStateToProps = state =>({
 ProductList:state.Product.pList,
 
})
const mapActionsToProps = {
  fetchAllProducts: action.fetchAllProduct,
  deleteProduct:action.Delete
  
}

export default connect(mapStateToProps,mapActionsToProps)(withStyles(styles)(Product))