/* eslint-disable eqeqeq */
/* eslint-disable react-hooks/exhaustive-deps */
import {Grid, TextField,withStyles,Button } from '@material-ui/core'
import React,{useEffect} from 'react'
import useForm from './useForm'
import { connect } from 'react-redux'
import * as actions from "../../../Redux/Actions/Groups/GroupAction";
import {useToasts}  from 'react-toast-notifications';


const styles = theme => ({
    root: {
      '& .MuiTextField-root': {
      margin: theme.spacing(1),
      minWidth:230
    }
  },
  formControl: {
    margin: theme.spacing(1),
      minWidth:230
  },
  smMargin: {
    margin: theme.spacing(1),
  }
})

const initialFieldValues = {
  groupName: '',
}

function GroupForm({classes, ...props }) {

  const { addToast } = useToasts();

  const validate = (fieldValues=values) => {
    let temp = {...errors};

    if ('groupName' in fieldValues) 
      temp.groupName = fieldValues.groupName ? "" : "This field is required."
    
    setErrors({
      ...temp
    })
         if ( fieldValues === values) 
    return Object.values(temp).every(x => x==="")
  }

const {
    values,
    setValues,
    errors,
          setErrors,          
    handelInputChange,
    resetForm
  }  = useForm(initialFieldValues,validate,props.setCurrentId)
  
  

 const handelSubmit = e => {
    e.preventDefault();
    if (validate()) {
      const onSuccess = () => {
        resetForm()
        addToast('Submitted Successfully', { appearance: 'success' })
      }
      if (props.currentId ===0) 
        props.createGroups(values, onSuccess)
      else 
         props.updateGroups(props.currentId,values, onSuccess)
    }
    
    }
      useEffect(() => {
        if (props.currentId!=0) {
          setValues({
           ...props.GroupList.find(x=>x.groupId===props.currentId)
          })
          setErrors({})
        }
      }, [props.currentId])

  return (
    


     <form autoComplete="off" noValidate className={classes.root} onSubmit={handelSubmit}>
          <Grid container>
               <Grid item xs={6}>
                    <TextField
                    name="groupName"
                    variant="outlined"
                    label="Group Name"
                    value={values.groupName}
                    onChange={handelInputChange}
                    {...(errors.groupName && { error: true, helperText:errors.groupName})}
                    />
         
               </Grid>
          <Grid item xs={6}>
          <div>
            <Button className={classes.smMargin} type="submit" variant="contained" color="primary">Submit</Button>
            <Button variant="contained" color="secondary" onClick={resetForm} >Reset</Button>
          </div>
        </Grid>
     </Grid>
    </form>
  )
}


const mapStateToProps = state =>({
 GroupList:state.Group.list
})

const mapActionsToProps = {
  createGroups:actions.create,
  updateGroups:actions.update
}
export default connect(mapStateToProps,mapActionsToProps) (withStyles(styles)(GroupForm))
