/* eslint-disable no-unused-vars */
/* eslint-disable react-hooks/exhaustive-deps */
import { Button, ButtonGroup, Grid, Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow } from '@material-ui/core'
import React, { useEffect, useState } from 'react'
import EditIcon from '@material-ui/icons/Edit'
import DeleteIcon from '@material-ui/icons/Delete'
import { useToasts } from 'react-toast-notifications';
import { connect } from 'react-redux'
import * as actions from "../../../Redux/Actions/Groups/GroupAction";
import GroupForm from './GroupForm'

function Group(props) {



  const { addToast } = useToasts();
   
  const [currentId, setCurrentId] = useState(0)

  
  useEffect(() => {
    props.fetchAllGroups()
  }, [])

  const onDelete = id => {
      if (window.confirm('Are you sure to delete this record?')) {
        props.deleteGroup(id,()=> addToast('Deleted Successfully', { appearance: 'info' }))
      }
    }
  return (
    <Paper style={{margin:'10px',padding:'15px'}} elevation={3} >
      <Grid container>
        <Grid item xs={6}>
           <GroupForm {...({currentId,setCurrentId})}/>
        </Grid>
        <Grid item xs={6}>
           <TableContainer>
             <Table>
               <TableHead>
                 <TableRow>
                   <TableCell>Group Name</TableCell>
                   <TableCell></TableCell>
                 </TableRow>
               </TableHead>
               <TableBody>
                 {
                   props.GroupList.map((record,index) => {
                     return (
                       <TableRow key={index} hover>
                         <TableCell>{ record.groupName}</TableCell>
                        
                         <TableCell>
                           <ButtonGroup variant="text">
                             <Button>
                               <EditIcon color="primary"onClick={() => { setCurrentId(record.groupId) }} />
                             </Button>
                             <Button ><DeleteIcon color="secondary"
                                onClick={()=> onDelete(record.groupId)}
                             /></Button>
                           </ButtonGroup>
                         </TableCell>
                      </TableRow>
                    )
                  })

                 }
               </TableBody>
             </Table>
          </TableContainer>
        </Grid>
      </Grid> 
    </Paper>
  )
}

const mapStateToProps = state =>({
 GroupList:state.Group.list
})

const mapActionsToProps = {
  fetchAllGroups: actions.fetchAll,
  deleteGroup:actions.Delete
}

export default connect(mapStateToProps,mapActionsToProps)(Group)
