import React,{useState} from 'react'

const useForm = (initialFieldValues, validate, setCurrentId) => {
  
  const [values, setValues] = React.useState(initialFieldValues);
  
  const [errors,setErrors]=useState({})
  
   const handelInputChange = e => {
     const { name, value } = e.target
     const fieldValue={ [name]: value}
    setValues({
      ...values,
      ...fieldValue
        
    })
     validate(fieldValue)
  }
  
  const resetForm = () => {
    setValues({
      ...initialFieldValues
    })
    setErrors({})
    setCurrentId(0)
  }
  return {
    values,
    setValues,
    errors,
    setErrors,
    handelInputChange,
    resetForm
  }
}

export default useForm
