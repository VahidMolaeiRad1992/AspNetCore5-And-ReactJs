import {Route,Link,BrowserRouter as Router,Switch} from 'react-router-dom'
import React from 'react'
import Group from './Groups/Group'
import SubGroup from './SubGroups/SubGroup'
import { AppBar, Toolbar, Typography } from '@material-ui/core'
import Product from './Products/Product'


export default function Index() {
  return (
       <Router>
        <AppBar position="static" color="secondary">
        <Toolbar>
          <Typography variant="h6" >
             Manage |
            </Typography>
            <Typography variant="h6" >
              <Link to="/group" style={{color:'white'}}>Group</Link> |
            </Typography>
            <Typography variant="h6" >
              <Link to="/subGroup" style={{color:'white'}}> SubGroup</Link> |
            </Typography>  
            <Typography variant="h6" >
              <Link to="/product" style={{color:'white'}}> Product</Link> |
            </Typography>  
          </Toolbar>
        </AppBar>
       <Switch>
      
        <Route exact path="/group"><Group/></Route>
        <Route  path="/subGroup"><SubGroup/></Route>
        <Route  path="/product"><Product/></Route>
      </Switch>
      
       </Router>
       
     
    
    
  )
}
