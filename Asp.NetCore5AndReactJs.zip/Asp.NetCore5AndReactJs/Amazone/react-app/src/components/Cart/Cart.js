/* eslint-disable jsx-a11y/alt-text */
import { Table,Grid,makeStyles, Paper , Button, TableContainer, TableCell,TableHead, TableRow, TableBody, TextField} from '@material-ui/core';
import React from 'react'
import { connect } from 'react-redux'
import DeleteIcon from '@material-ui/icons/Delete'
import * as action from '../../Redux/Reducers/ShoppingCart/shopping-actions'
import {createOrder} from '../../Redux/Order/Order-actions'
import axios from 'axios';


const useStyles = makeStyles(theme =>({
	root: {
		'& .MuiTableCell-head': {
		fontFamily:'tahoma',
		fontSize:"1.25rem"
	     },
		'& .MuiTableCell-body': {
		fontFamily:'tahoma',
		fontSize:"1.30rem"
		},
		'& .MuiTextField-root': {
			margin: theme.spacing(1),
			minWidth:230
		   }
	},
	paper:{
		padding:'2rem',	
	},
	cart:{
		
		padding:theme.spacing(2)

	},
	detail:{
		
		padding:theme.spacing(2),
		margin:theme.spacing(2)

	},
	button:{
		margin:theme.spacing(2)
	},
	blockquote:{
		textAlign:'center',
		padding:theme.spacing(2),
		margin:theme.spacing(2),
		backgroundColor:'rgb(24, 214, 173)',
		fontFamily:'Ubuntu Mono'
	}

	
   }));

   const initialFieldValues={
	fullName:'',
	email:'',
	mobileNumber:'',
	phoneNumber:'',
	address:'',
	showCheckout: false,
}

function Cart(props) {
	const classes = useStyles();
	const [values, setValues] = React.useState(initialFieldValues);


	const TAX_RATE = 0.07;
	
	const invoiceTaxes = TAX_RATE *props.cartProp.reduce((a,c)=>a+c.price * c.count,0) ;
	const invoiceTotal = props.cartProp.reduce((a,c)=>a+c.price * c.count,0)-invoiceTaxes ;
	const onDelete =product=>{
		if (window.confirm('Are you sure to delete this record?')) {
			props.deleteItemCart(product)
		   }
	}

	const handelChangeInput=e=>{
		let {name,value}=e.target
		setValues({
			...values,
			[name]:value
	     })
	}
	
	const submittedOrder = (e) => {
		e.preventDefault();
		const order = {
		  	fullName: values.fullName,
		  	email: values.email,
			mobileNumber:values.mobileNumber,
			phoneNumber:values.phoneNumber,  
		  	address: values.address,
		  	cartItems: props.cartProp,
		  	total: props.cartProp.reduce((a,c)=>a+c.price * c.count,0),
		};
		console.log(order);
		//axios.post('https://localhost:44364/api/Order/',order)
		//.then(res=>{
		//	alert('Success')
		//})
		props.submitOrder(order);
	   };


	return (
		<div>
		<Paper elevation={8} >
			<Grid container>
			<Grid item xs></Grid>
			<Grid item xs={10}>	
			<blockquote className={classes.blockquote}>
				<h3>نمایش جزئیات سفارش</h3>
			</blockquote>
			<TableContainer elevation={8} component={Paper} style={{direction:'rtl'}} >
				<Table className={classes.root} aria-label="spanning table">

			
				<TableHead className={classes.root}>
					<TableRow>
					<TableCell>شماره</TableCell>
					<TableCell>عنوان</TableCell>
					<TableCell>تعداد</TableCell>
					<TableCell>قیمت</TableCell>
					<TableCell>حذف</TableCell>
					<TableCell>تصویر</TableCell>
					
					</TableRow>
				</TableHead>
				<TableBody>
					{
						props.cartProp.map((record,index)=>{
							return(
								<TableRow key={index}>
									<TableCell>{index}</TableCell>
									<TableCell>{record.title}</TableCell>
									<TableCell>{record.count}</TableCell>
									<TableCell>تومان{record.price}</TableCell>
									<TableCell>
									<Button >
										<DeleteIcon fontSize="large"  color="secondary"
											onClick={()=>onDelete(record) }
										/>
									</Button>
									</TableCell>
									
									<TableCell>
										
										<img src={record.imageSrc} alt={record.title} width="20%" height="10%"/>
										
									</TableCell>
									
								</TableRow>

							)
								
							
						})
					}
						<TableRow align="center">
							<TableCell rowSpan={4} />
							<TableCell colSpan={2}>مبلغ خرید:</TableCell>
							<TableCell align="center">تومان{props.cartProp.reduce((a,c)=>a+c.price * c.count,0)}</TableCell>
							</TableRow>
							<TableRow>
							<TableCell colSpan={2}>تخفیف:</TableCell>
							<TableCell  align="right">{`${(TAX_RATE * 100).toFixed(0)} %`}</TableCell>
							<TableCell align="right">{(invoiceTaxes).toFixed(2)}</TableCell>
							</TableRow>
							<TableRow>
							<TableCell colSpan={2}>قیمت کل:</TableCell>
							<TableCell align="right">{invoiceTotal}</TableCell>
						</TableRow>
				</TableBody>
				</Table>
				<Button 
				className={classes.button}variant="contained" color="primary"
				onClick={() => {
					setValues({ showCheckout: true });
				   }}
				>ادامه</Button>
			</TableContainer>
				   {values.showCheckout &&(
					   <form noValidate autoComplete="off" onSubmit={submittedOrder}>
					   <Paper elevation={12} className={classes.root}>
						   <Grid container>
							   <Grid item xs={6} className={classes.cart}>
								   <TextField 
								   className={classes.root}
								   name="fullName"
								   label="نام و نام خانوادگی"
								   value={values.fullName}
								   onChange={handelChangeInput}
								   />
								   <br/>
								   <TextField 
								   className={classes.root}
								   name="email"
								   label="پست الکترونیک"
								   value={values.email}
								   onChange={handelChangeInput}
								   /><br/>
								   <TextField 
								   className={classes.root}
								   name="mobileNumber"
								   label="موبایل"
								   value={values.mobileNumber}
								   onChange={handelChangeInput}
								   />
							   </Grid>
							   <Grid item xs={6}>
								   <TextField 
									   className={classes.root}
									   name="phoneNumber"
									   label="تلفن منزل"
									   value={values.phoneNumber}
									   onChange={handelChangeInput}
								   /><br/>
								   <TextField 
									   className={classes.root}
									   name="address"
									   multiline
									   rows={4}
									   label="آدرس"
									   value={values.address}
									   onChange={handelChangeInput}
								   />
					   
							   </Grid>
				   
						   </Grid>
						   <Grid container>
							   <Grid xs></Grid>
							   <Grid xs={6}>
							   <Button className={classes.button} type="submit" variant="contained" color="primary">ثبت نهایی سفارش</Button>
							   &nbsp;&nbsp;&nbsp;&nbsp;
							   <Button className={classes.button} variant="contained" color="secondary"  >لغو</Button>
							   </Grid>
							   <Grid xs></Grid>
						   </Grid>
			   
				    </Paper>
   
				   </form>
			   
				   )}

				
			</Grid>
			<Grid item xs></Grid>
			</Grid>
			
		</Paper>




		</div>
	)
}

const mapStateToProps = (state) => {
	return {
		cartProp: state.shopCart.cartItems
	}
}

const mapActionsToProps = {
	deleteItemCart:action.removeFromCart,
	submitOrder:createOrder
   }
export default connect(mapStateToProps,mapActionsToProps)(Cart)