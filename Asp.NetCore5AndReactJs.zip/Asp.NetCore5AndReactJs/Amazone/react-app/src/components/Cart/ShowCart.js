import { Paper } from '@material-ui/core'
import React from 'react'
import { connect } from 'react-redux'
import ShoppingCart from '@material-ui/icons/ShoppingCart'
function ShowCart(props) {
	return (
		<Paper elevation={8} style={{padding:'1.25rem'}}>
			<h3  style={{textAlign:'center',padding:'1rem',color:'white',fontFamily:'ubuntu',backgroundColor:'rgb(39, 170, 137)'}}>سبد خرید &nbsp;<ShoppingCart/></h3>
			{
				props.cartProp.map((record,index)=>{
					return(
						<div key={index} style={{padding:'1rem',direction:'rtl',textAlign:'right'}}>
							<span style={{padding:'1rem'}}><strong>{index+1}</strong></span>-
							<span style={{padding:'1rem'}}><strong>{record.title}</strong></span>
							<span style={{padding:'1rem',backgroundColor:'rgb(221, 69, 23)',color:'white',borderRadius:'35px',fontSize:'1rem'}}>{record.count}</span>
							&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							<img style={{textAlign:'left'}} src={record.imageSrc} alt={record.title} width="10%" height="10%"/>
						</div>
						
					)
				})
			}
			<hr/>
			<p style={{textAlign:'center',padding:'1.25rem'}}>
				<strong>
				جمع کل:&nbsp;{props.cartProp.reduce((a,c)=>a+c.price * c.count,0)}&nbsp;تومان
				</strong>
			</p>
		</Paper>
	)
}

const mapStateToProps = (state) => {
	return {
		cartProp: state.shopCart.cartItems
	}
}
export default connect(mapStateToProps)(ShowCart)
