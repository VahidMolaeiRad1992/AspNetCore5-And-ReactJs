import React from 'react'
import Product from '../Products/Product'
import ShowCart from '../Cart/ShowCart'
import './Home.css'


function Home() {
	return (
		<div>
			<div className="content">
				<div className="main">
				<Product />
				</div>
				<div className="cart">
					<ShowCart />
				</div>
				

			</div>
		</div>
	)
}

export default Home
