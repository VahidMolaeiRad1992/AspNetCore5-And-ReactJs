import {Route,Link,BrowserRouter as Router,Switch} from 'react-router-dom'
import React from 'react'
import Index from './Admin/Index'
import { AppBar, Badge, Toolbar, Typography} from '@material-ui/core'
import Home from './Home/Home'

import { connect } from 'react-redux';
import Cart from './Cart/Cart'
import ShoppingCart from '@material-ui/icons/ShoppingCart'



function Navbar(props) {

	
	
	return (
		<Router>
			<AppBar position="static">
				<Toolbar>
				<Typography >
						<Link to="/home" 
						style={{textDecoration:'none',
						fontSize:'1.6rem',color:'#ffffff',
						padding:'0.8rem',
						marginLeft:'5px'}}
						>Home
						</Link>
					</Typography>
					<Typography >
						<Link to="/indexAdmin" style={{
								textDecoration:'none',
								fontSize:'1.6rem',
								color:'#ffffff'}}
						>Admin
						</Link>
					</Typography>&nbsp; &nbsp;&nbsp;
					<Typography>
						
						<Badge badgeContent={props.cartProp.length} color="secondary">
						<Link to="/cart"  style={{
								textDecoration:'none',
								fontSize:'1.6rem',
								color:'#ffffff'}}>
						<ShoppingCart />
						
						
						</Link>
						</Badge>
					</Typography>
				</Toolbar>			
			</AppBar>
			
			
			<Switch className="content">
				<Route exact path="/"><Home/></Route>
				<Route exact path="/home"><Home/></Route>
				<Route exact path="/indexAdmin"><Index/></Route>
				<Route exact path="/cart"><Cart/></Route>
				
			</Switch>
			
		</Router>
	)
}

const mapStateToProps = (state) => {
	return {
		cartProp: state.shopCart.cartItems
	}
}

export default connect(mapStateToProps)(Navbar)