/* eslint-disable jsx-a11y/img-redundant-alt */
import React from 'react'
import axios from 'axios';
import { Button, Card, CardActionArea, CardActions, CardContent, CardMedia,Grid,Icon,Paper,Typography } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import ShoppingCart from '@material-ui/icons/ShoppingCart'

import {addToCart} from '../../Redux/Reducers/ShoppingCart/shopping-actions'
import { connect } from 'react-redux';


const useStyles = makeStyles( theme=>({
	root: {
	  	maxWidth: 345,
		padding: theme.spacing(2),
		flexGrow: 1,
		textAlign: 'center',
	},
	paper: {
		padding: theme.spacing(2),
		margin: theme.spacing(2),
		textAlign: 'center',
		fontFamily:'Tahoma'
	   },
	media: {
		height: 280,
		width:'100%',
		objectFit: 'cover'
	},
	button:{
		backgroundColor:'#3f51f3',
		color:'white',
		marginRight:'3rem',
		marginLeft:'3rem',
		"&:hover": {
			//you want this to be the same as the backgroundColor above
			backgroundColor: "#03026b"
		 }
	},
	
	
}));

function Product(props) {
	
	const [productList, setProductList] = React.useState([])

 	const ProductAPI= (url='https://localhost:44364/api/Product/')=>{

	   return {
		fetchAllProduct: () => axios.get(url),
		fetchByIdProduct:id=>axios.get(url+id),
	   }
  }

	React.useEffect(() => {
		ProductList();
	 },[]) 

	function ProductList() {
		ProductAPI().fetchAllProduct()
		    .then(res => {
			 setProductList(res.data)
			
		    })
		   .catch(err => console.log(err))
		 
    }
    const classes = useStyles();

   
    
    
	return (
		<div >
			<h1 style={{textAlign:'center',padding:'2rem',color:'rgb(3, 17, 100)'}}>محصولات فروشگاه آمازون  </h1>
		<Paper>
			<Grid container spacing={2} >
			{
				productList.map((record,index)=>{
					return(
						<Grid item xs={4} key={index}>

							<Card  className={classes.paper} key={index}>
							<CardActionArea>
								<CardMedia className={classes.media}
									image={record.imageSrc}
									title={record.title}
								/>
									<CardContent>
										<Typography gutterBottom variant="h5" component="h2">
									
										{record.title}
										</Typography>
										<Typography variant="body2" color="textSecondary" component="p">
										{record.description}
										</Typography>
										<Typography variant="h6"  component="h3">
										تومان	{record.price} 
										</Typography>
									</CardContent>
								</CardActionArea>
								<CardActions>
									<Button size="large"  className={classes.button} startIcon={<ShoppingCart />}
										onClick={()=>props.addToCart(record)}
									>
										Add To Card
									</Button>
									
								</CardActions>
						</Card>
						</Grid>		
					)
				})
			}
			</Grid>
		</Paper>

		
		</div>
	)
}

 export default connect(null,{addToCart})(Product) 
