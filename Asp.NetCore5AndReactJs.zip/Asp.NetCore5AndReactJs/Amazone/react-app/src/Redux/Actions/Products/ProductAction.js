import ProductAPI from './ProductAPI';

export const ACTION_TYPES_PRODUCT = {
  CREATE_PRODUCT: 'CREATE_PRODUCT',
  UPDATE_PRODUCT : 'UPDATE_PRODUCT',
  DELETE_PRODUCT: 'DELETE_PRODUCT',
  FETCH_ALL_PRODUCT:'FETCH_ALL_PRODUCT'  
}



export const fetchAllProduct = () => dispatch => {
  ProductAPI().fetchAll()
    .then(res => {    
        dispatch({
          type: ACTION_TYPES_PRODUCT.FETCH_ALL_PRODUCT,
          payload:res.data,
        })
	
      }
    )
    .catch(err =>console.log(err))
 
} 

export const create = (data, onSuccess) => dispatch => {

     ProductAPI.ProductAPI().createProduct(data)
    .then(res => {
      dispatch({
        type: ACTION_TYPES_PRODUCT.CREATE_PRODUCT,
        payload:res.data
      })
      onSuccess()
    })
  .catch(err =>console.log(err))
}
export const update = (id,data, onSuccess) => dispatch => {
	
     ProductAPI.ProductAPI().updateProduct(id,data)
	.then(res => {
		dispatch({
		type: ACTION_TYPES_PRODUCT.UPDATE_PRODUCT,
		payload:{id,...data}
		})
		onSuccess()
	})
  	.catch(err =>console.log(err))
}
export const Delete = (id, onSuccess) => dispatch => {
   ProductAPI.Product().deleteProduct(id)
	.then(res => {
      dispatch({
        type: ACTION_TYPES_PRODUCT.DELETE_PRODUCT,
        payload:id
      })
      onSuccess()
    })
  .catch(err =>console.log(err))
}