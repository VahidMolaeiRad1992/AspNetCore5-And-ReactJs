import axios from 'axios';



const BaseURL = "https://localhost:44364/api/Product/";

// eslint-disable-next-line import/no-anonymous-default-export
export default {
     ProductAPI(url=BaseURL){
	     return {

			fetchAll: () => axios.get(url),
			fetchByIdProduct:id=>axios.get(url+id),
			createProduct: newRecord => axios.post(url, newRecord),
			updateProduct: (id, updateRecord) => axios.put(url + id, updateRecord),
			deleteProduct:id=>axios.delete(url+id)
	     }
     }
}