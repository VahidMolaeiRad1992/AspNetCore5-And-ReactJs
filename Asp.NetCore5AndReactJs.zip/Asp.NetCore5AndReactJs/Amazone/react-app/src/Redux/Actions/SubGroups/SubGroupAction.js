import SubGroupAPI from './SubGroupAPI'



export const ACTION_TYPES_SUBGROUP = {
  CREATE_SUBGROUP: 'CREATE_SUBGROUP',
  UPDATE_SUBGROUP : 'UPDATE_SUBGROUP',
  DELETE_SUBGROUP: 'DELETE_SUBGROUP',
  FETCH_ALL_SUBGROUP:'FETCH_ALL_SUBGROUP'  
}



export const fetchAll = () => dispatch => {
	SubGroupAPI.subGroup().fetchAllSubGroup()
	  .then(
	    response => {
		 dispatch({
		   type: ACTION_TYPES_SUBGROUP.FETCH_ALL_SUBGROUP,
		   payload:response.data
		 })
	    
	    }
	  )
	  .catch(err =>console.log(err))
    
   } 
export const createSubGroup = (data, onSuccess) => dispatch => {

  SubGroupAPI.subGroup().createSubGroup(data)
    .then(res => {
      dispatch({
        type:ACTION_TYPES_SUBGROUP.CREATE_SUBGROUP,
        payload:res.data
      })
      onSuccess()
    })
  .catch(err =>console.log(err))
}
export const update = (id,data, onSuccess) => dispatch => {

  SubGroupAPI.subGroup().updateSubGroup(id,data)
    .then(res => {
      dispatch({
        type: ACTION_TYPES_SUBGROUP.UPDATE_SUBGROUP,
        payload:{id,...data}
      })
      onSuccess()
    })
  .catch(err =>console.log(err))
}
export const Delete = (id, onSuccess) => dispatch => {
   SubGroupAPI.subGroup().deleteSubGroup(id)
	.then(res => {
      dispatch({
        type: ACTION_TYPES_SUBGROUP.DELETE_SUBGROUP,
        payload:id
      })
      onSuccess()
    })
  .catch(err =>console.log(err))
}