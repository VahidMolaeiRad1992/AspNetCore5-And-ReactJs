import axios from 'axios';

const BaseURL = "https://localhost:44364/api/";

// eslint-disable-next-line import/no-anonymous-default-export
export default  {

	subGroup(url=BaseURL+'SubGroup/') {
    return {
      fetchAllSubGroup: () => axios.get(url),
      fetchByIdSubGroup:id=>axios.get(url+id),
      createSubGroup: newRecord => axios.post(url, newRecord),
      updateSubGroup: (id, updateRecord) => axios.put(url + id, updateRecord),
      deleteSubGroup:id=>axios.delete(url+id)
    }
  }

  

}