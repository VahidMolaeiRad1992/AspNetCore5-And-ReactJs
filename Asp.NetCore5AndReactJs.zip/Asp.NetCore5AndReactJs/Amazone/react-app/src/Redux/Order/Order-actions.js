import {CREATE_ORDER} from './Order-types';
import {FETCH_ORDERS} from './Order-types';
import axios from 'axios';

const BaseURL = "https://localhost:44364/api/Order/";



export const fetchAllOrder = () => dispatch => {
	axios.get(BaseURL)
	  .then(
	    response => {
		 dispatch({
		   type:FETCH_ORDERS ,
		   payload:response.data
		 })
	    }
	  )
	  .catch(err =>console.log(err))
   } 
   
export const createOrder = (data) => dispatch => {
		axios.post(BaseURL,data)
	  .then(res => {
	    dispatch({
		 type: CREATE_ORDER,
		 payload:res.data
	    })
	  })
	.catch(err =>console.log(err))
   }