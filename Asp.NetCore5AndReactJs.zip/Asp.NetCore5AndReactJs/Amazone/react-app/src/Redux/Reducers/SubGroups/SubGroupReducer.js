import {  ACTION_TYPES_SUBGROUP} from '../../Actions/SubGroups/SubGroupAction';


const INITIAL_STATE = {
	subList:[]
};
 
export const SubGroup =(state = INITIAL_STATE, action) => {
  switch (action.type) {
    case  ACTION_TYPES_SUBGROUP.FETCH_ALL_SUBGROUP:
      return { ...state,
        subList:[...action.payload]
      }
    case  ACTION_TYPES_SUBGROUP.CREATE_SUBGROUP:
      return {
        ...state,
        subList:[...state.subList,action.payload]
      }
    case  ACTION_TYPES_SUBGROUP.UPDATE_SUBGROUP:
      return {
        ...state,
        subList:state.subList.map(x=>x.id===action.payload.id ?action.payload:x)
      }
    case  ACTION_TYPES_SUBGROUP.DELETE_SUBGROUP:
      return {
        ...state,
        subList:state.subList.filter(x=>x.id !==action.payload)
      }
    default:
      return state
  }
}

