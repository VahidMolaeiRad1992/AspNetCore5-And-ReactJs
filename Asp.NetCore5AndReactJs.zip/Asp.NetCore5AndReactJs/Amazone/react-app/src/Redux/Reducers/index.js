import { combineReducers } from "redux";
import { Group } from './Groups/GroupReducer';
import {SubGroup} from './SubGroups/SubGroupReducer';
import {Product} from './Products/ProductReducer';
import shopReducer from './ShoppingCart/Shopping-reducer'
import { orderReducer } from '../Order/Order-reducer'

const reducers = combineReducers({
		Group, SubGroup,Product,shopCart:shopReducer,order:orderReducer
})


export default reducers