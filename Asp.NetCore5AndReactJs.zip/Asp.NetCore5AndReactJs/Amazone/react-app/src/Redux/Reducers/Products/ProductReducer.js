import {ACTION_TYPES_PRODUCT} from '../../Actions/Products/ProductAction';



const INITIAL_STATE = {
	pList:[]
	
};
 

export const Product =(state = INITIAL_STATE, action) => {
	
  switch (action.type) {
    case ACTION_TYPES_PRODUCT.FETCH_ALL_PRODUCT:
      return { ...state,
	   pList:[...action.payload],
	 
      }
    case ACTION_TYPES_PRODUCT.CREATE_PRODUCT:
      return {
        ...state,
        pList:[...state.pList,action.payload]
      }
    case ACTION_TYPES_PRODUCT.UPDATE_PRODUCT:
      return {
        ...state,
        pList:state.pList.map(x=>x.id===action.payload.id ?action.payload:x)
      }
    case ACTION_TYPES_PRODUCT.DELETE_PRODUCT:
      return {
        ...state,
        pList:state.pList.filter(x=>x.id !==action.payload)
      }
    default:
      return state
  }
}

