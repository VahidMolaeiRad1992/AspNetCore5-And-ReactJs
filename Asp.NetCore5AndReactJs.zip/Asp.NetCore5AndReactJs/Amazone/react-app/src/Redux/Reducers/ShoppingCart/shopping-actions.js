import * as actionTypes from './Shopping-types'

export const addToCart=(product)=> (dispatch,getState)=>{
	const cartItems=getState().shopCart.cartItems.slice();
	let alreadyExist=false;
	cartItems.forEach((x)=>{
		if(x.productId===product.productId){
			alreadyExist=true
			x.count++;
		}
	});
		if (!alreadyExist) {
			cartItems.push({...product,count:1})
		}
	dispatch({
		type:actionTypes.ADD_TO_CART,
		payload:{cartItems},
	});
	localStorage.setItem("cartItems",JSON.stringify(cartItems));
}
export const removeFromCart=(product)=> (dispatch,getState)=>{
	const cartItems=getState().shopCart.cartItems.slice().filter((x)=>x.productId !== product.productId);
	dispatch({
		type:actionTypes.REMOVE_FROM_CART,
		payload:{cartItems}
	})
	localStorage.setItem("cartItems",JSON.stringify(cartItems))
}

