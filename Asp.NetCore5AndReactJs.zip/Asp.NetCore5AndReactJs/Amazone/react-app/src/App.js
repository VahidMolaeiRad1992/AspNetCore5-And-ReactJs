import { Provider } from 'react-redux';
import { ToastProvider } from 'react-toast-notifications';
import './App.css';
import Navbar from './components/Navbar';
import  store   from './Redux/store'



function App() {
  	return (
     	<ToastProvider autoDismiss={true}>
     		<Provider store={store}>	
			<Navbar/>	
			</Provider>
		</ToastProvider>
	);
}

export default App;
